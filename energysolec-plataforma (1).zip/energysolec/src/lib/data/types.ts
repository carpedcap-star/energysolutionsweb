export type Segment = 'residencial' | 'comercial' | 'industrial';
export type LeadStage = 'nuevo' | 'contactado' | 'calificado' | 'visita_tecnica' | 'cotizacion_enviada' | 'negociacion' | 'ganado' | 'perdido';
export type LeadSource = 'calculadora' | 'tienda' | 'contacto' | 'cotizacion' | 'catalogo' | 'financiamiento' | 'capacitacion' | 'campana' | 'servicio';
export type OrderStatus = 'nuevo' | 'pendiente_contacto' | 'contactado' | 'cotizado' | 'confirmado' | 'pagado' | 'en_preparacion' | 'despachado' | 'entregado' | 'cancelado';
export type AppRole = 'superadmin' | 'gerencia' | 'marketing' | 'ventas' | 'ingenieria' | 'compras';

export const LEAD_STAGES: { id: LeadStage; label: string }[] = [
  { id: 'nuevo', label: 'Nuevo lead' }, { id: 'contactado', label: 'Contactado' }, { id: 'calificado', label: 'Calificado' },
  { id: 'visita_tecnica', label: 'Visita técnica' }, { id: 'cotizacion_enviada', label: 'Cotización enviada' },
  { id: 'negociacion', label: 'Negociación' }, { id: 'ganado', label: 'Ganado' }, { id: 'perdido', label: 'Perdido' },
];
export const ORDER_STATUSES: { id: OrderStatus; label: string }[] = [
  { id: 'nuevo', label: 'Nuevo' }, { id: 'pendiente_contacto', label: 'Pendiente de contacto' }, { id: 'contactado', label: 'Contactado' },
  { id: 'cotizado', label: 'Cotizado' }, { id: 'confirmado', label: 'Confirmado' }, { id: 'pagado', label: 'Pagado' },
  { id: 'en_preparacion', label: 'En preparación' }, { id: 'despachado', label: 'Despachado' }, { id: 'entregado', label: 'Entregado' },
  { id: 'cancelado', label: 'Cancelado' },
];
export const PAID_STATES: OrderStatus[] = ['pagado', 'en_preparacion', 'despachado', 'entregado'];

export type Lead = {
  id: string; full_name: string; email: string; phone?: string | null; company?: string | null;
  segment?: Segment | null; province?: string | null; city?: string | null;
  monthly_kwh?: number | null; monthly_bill_usd?: number | null; recommended_kwp?: number | null; estimated_investment_usd?: number | null;
  source: LeadSource; utm: Record<string, string>; stage: LeadStage; advisor_id?: string | null;
  next_activity_at?: string | null; next_activity_note?: string | null; notes?: string | null;
  first_contact_at?: string | null; created_at: string;
};

export type Study = {
  id: string; code: string; lead_id: string | null; mode: 'rapida' | 'profesional';
  inputs: unknown; results: import('../engine/study').StudyResult; params_version: number; solar_source: string;
  unlocked: boolean; visit_requested: boolean; created_at: string;
};

export type Product = {
  id: string; sku: string; slug: string; name: string; brand: string | null; model: string | null;
  category: string; summary: string | null; specs: Record<string, string | number>; warranty: string | null;
  certifications: string[]; images: string[]; datasheet_url: string | null; vat_rate: number; stock: number;
  availability: 'disponible' | 'bajo_pedido' | 'agotado' | 'consultar'; installable: boolean;
  price: number; promo_price: number | null; is_placeholder: boolean; published: boolean;
};

export type OrderItem = { product_id: string; sku: string; name: string; qty: number; unit_price: number; vat_rate: number; line_subtotal: number };
export type Order = {
  id: string; number: string; lead_id: string | null; customer_name: string; email: string; phone: string; city: string; address: string;
  customer_type: 'final' | 'instalador' | 'distribuidor' | 'empresa'; notes: string | null; needs_installation: boolean;
  subtotal: number; tax: number; total: number; status: OrderStatus; payment_reference: string | null;
  payment_verified_by: string | null; payment_verified_at: string | null; whatsapp_message: string; items: OrderItem[]; created_at: string;
};

export type Stat = { id: string; label: string; value: number; unit: string | null; source_note: string; verified: boolean; sort: number };
export type Project = {
  id: string; slug: string; title: string; client_name: string | null; segment: Segment; industry: string | null;
  province: string | null; city: string | null; lat: number | null; lng: number | null; location_authorized: boolean;
  capacity_kwp: number | null; inverter_kw: number | null; panel_count: number | null; installation_type: string | null;
  technology: string[]; annual_generation_kwh: number | null; generation_is_measured: boolean; annual_savings_usd: number | null;
  co2_avoided_t: number | null; executed_on: string | null; status: string; description: string | null;
  testimonial: string | null; testimonial_author: string | null; cover: string | null; published: boolean; featured: boolean; is_placeholder: boolean;
};
export type Brand = { id: string; slug: string; name: string; logo: string | null; description: string | null; relationship: string | null; relationship_verified: boolean; published: boolean };
export type Consent = { purpose: 'privacidad_servicio' | 'comercial_marketing'; granted: boolean };
export type Staff = { id: string; email: string; full_name: string; role: AppRole };
export type Activity = { id: string; lead_id: string; kind: string; body: string | null; at: string; actor: string | null };
